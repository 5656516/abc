package com.xiaofeng.screentranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * v2 main screen: permissions + EN->ZH model status + start/stop. Nothing else —
 * the app does exactly one thing: translate English on screen into Chinese, in place.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvModelStatus: TextView
    private lateinit var tvServiceStatus: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private val modelStatusListener: (EnZhTranslator.ModelStatus) -> Unit = { status ->
        runOnUiThread { renderModelStatus(status) }
    }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                TranslatorService.start(this, result.resultCode, result.data!!)
                updateServiceUi(running = true)
                Toast.makeText(this, "悬浮按钮已启动，点「译」即可把当前页英文翻成中文", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "没有获得录屏授权，悬浮按钮未启动", Toast.LENGTH_SHORT).show()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvModelStatus = findViewById(R.id.tvModelStatus)
        tvServiceStatus = findViewById(R.id.tvServiceStatus)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        // Model status: tapping it after a failed download retries the download.
        tvModelStatus.setOnClickListener {
            if (EnZhTranslator.status == EnZhTranslator.ModelStatus.FAILED) {
                EnZhTranslator.ensureModelDownloaded()
                Toast.makeText(this, "正在重新下载翻译模型…", Toast.LENGTH_SHORT).show()
            }
        }

        // Kick off the EN->ZH model download right away so it's ready before the
        // floating button is ever tapped, and keep the status line live.
        EnZhTranslator.ensureModelDownloaded()
        EnZhTranslator.addStatusListener(modelStatusListener)

        btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先开启悬浮窗权限（第 1 步）", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            requestNotificationPermissionIfNeeded()
            // Android requires fresh user consent for screen capture on every start.
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }

        btnStop.setOnClickListener {
            TranslatorService.stop(this)
            updateServiceUi(running = false)
        }
    }

    override fun onDestroy() {
        EnZhTranslator.removeStatusListener(modelStatusListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        val granted = Settings.canDrawOverlays(this)
        tvOverlayStatus.text = if (granted) "状态：已开启 ✓" else "状态：未开启"
        updateServiceUi(TranslatorService.isRunning)
    }

    private fun renderModelStatus(status: EnZhTranslator.ModelStatus) {
        tvModelStatus.text = when (status) {
            EnZhTranslator.ModelStatus.UNKNOWN -> "翻译模型：准备中…"
            EnZhTranslator.ModelStatus.DOWNLOADING -> "翻译模型：下载中…（只需下载一次）"
            EnZhTranslator.ModelStatus.READY -> "翻译模型：已就绪 ✓"
            EnZhTranslator.ModelStatus.FAILED -> "翻译模型：下载失败，点这里重试（请确认已联网）"
        }
    }

    private fun updateServiceUi(running: Boolean) {
        tvServiceStatus.text = if (running) "悬浮按钮：运行中" else "悬浮按钮：未启动"
        btnStart.isEnabled = !running
        btnStop.isEnabled = running
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
