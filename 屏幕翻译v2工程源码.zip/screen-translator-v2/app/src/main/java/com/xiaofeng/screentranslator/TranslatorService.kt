package com.xiaofeng.screentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * v2 foreground service (type: mediaProjection). ONE job only: English -> Chinese,
 * in place, on the current page.
 *
 * Flow when the floating "译" button is tapped:
 *  1. Hide the button, grab the latest full-resolution screenshot frame.
 *  2. OCR (ML Kit Latin recognizer only) on the full image AND on 3 overlapping
 *     horizontal tiles; merge + deduplicate the lines so no English is missed.
 *  3. Translate every line individually (EN->ZH). Numbers/symbols-only lines are
 *     kept unchanged; garbage lines are filtered out (see [applyLineFilter]).
 *  4. Draw a full-screen overlay ON the current page: each line's Chinese text is
 *     drawn in an opaque box exactly over its original position. No result panel,
 *     no second page. Tap anywhere to dismiss; the floating button stays on top.
 */
class TranslatorService : Service() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var floatButton: TextView? = null
    private var floatParams: WindowManager.LayoutParams? = null

    private var indicatorView: TextView? = null
    private var translationOverlay: TranslationOverlayView? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private val frameLock = Any()
    private var latestFrame: Bitmap? = null

    private var busy = false

    private val latinRecognizer: TextRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (isRunning) return START_NOT_STICKY
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
                if (data == null) {
                    Toast.makeText(this, "录屏授权数据无效，请重新启动", Toast.LENGTH_SHORT).show()
                    stopSelf()
                    return START_NOT_STICKY
                }
                startCapture(resultCode, data)
            }
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ setup

    private fun startCapture(resultCode: Int, data: Intent) {
        startForegroundWithNotification()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mpm.getMediaProjection(resultCode, data)
        mediaProjection = projection
        // Required on Android 14+: a callback must be registered before creating a virtual display.
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { stopSelf() }
            }
        }, mainHandler)

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        captureThread = HandlerThread("screen-capture").apply { start() }
        captureHandler = Handler(captureThread!!.looper)

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ r ->
            val image = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            } ?: return@setOnImageAvailableListener
            try {
                val bmp = imageToBitmap(image, width, height)
                if (bmp != null) {
                    synchronized(frameLock) {
                        val old = latestFrame
                        latestFrame = bmp
                        if (old != null && old !== bmp && !old.isRecycled) old.recycle()
                    }
                }
            } catch (e: Exception) {
                // ignore single bad frame
            } finally {
                image.close()
            }
        }, captureHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "screen-translator-v2",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, captureHandler
        )

        showFloatingButton(width)
        isRunning = true
        // The English->Chinese model must be ready before the button can translate.
        EnZhTranslator.ensureModelDownloaded()
    }

    private fun startForegroundWithNotification() {
        val channelId = "screen_translator_service"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "屏幕翻译", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("屏幕翻译运行中")
            .setContentText("点悬浮的「译」按钮，把当前页的英文翻译成中文")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // ------------------------------------------------------- floating button

    private fun showFloatingButton(screenWidth: Int) {
        val size = dp(58)
        val button = TextView(this).apply {
            text = "译"
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#3F7FBF"))
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(6).toFloat()
        }
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth - size - dp(14)
            y = dp(220)
        }
        button.setOnTouchListener(FloatingTouchListener(params, button) { onTranslateTap() })
        windowManager.addView(button, params)
        floatButton = button
        floatParams = params
    }

    /** Distinguishes tap from drag on the floating button. */
    private inner class FloatingTouchListener(
        private val params: WindowManager.LayoutParams,
        private val view: View,
        private val onTap: () -> Unit
    ) : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var downTime = 0L

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    downTime = System.currentTimeMillis()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = abs(event.rawX - touchX) + abs(event.rawY - touchY)
                    if (moved < dp(10) && System.currentTimeMillis() - downTime < 400) {
                        onTap()
                    }
                    return true
                }
            }
            return false
        }
    }

    // ------------------------------------------------------------ tap flow

    private fun onTranslateTap() {
        // Tapping the button while the translation overlay is up dismisses it.
        if (translationOverlay != null) {
            dismissTranslationOverlay()
            return
        }
        if (busy) return
        if (!EnZhTranslator.isReady) {
            EnZhTranslator.ensureModelDownloaded()
            Toast.makeText(this, "模型下载中，请稍候", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        // Hide our own button so it doesn't end up in the screenshot.
        floatButton?.visibility = View.INVISIBLE
        mainHandler.postDelayed({
            val snapshot = snapshotFrame()
            floatButton?.visibility = View.VISIBLE
            if (snapshot == null) {
                Toast.makeText(this, "截图失败，请再点一次", Toast.LENGTH_SHORT).show()
                busy = false
                return@postDelayed
            }
            showIndicator()
            runOcrPipeline(snapshot)
        }, 260)
    }

    private fun snapshotFrame(): Bitmap? {
        synchronized(frameLock) {
            val frame = latestFrame ?: return null
            if (frame.isRecycled) return null
            return Bitmap.createBitmap(frame)
        }
    }

    private fun imageToBitmap(image: android.media.Image, width: Int, height: Int): Bitmap? {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val bmp = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        bmp.copyPixelsFromBuffer(buffer)
        if (rowPadding == 0) return bmp
        val cropped = Bitmap.createBitmap(bmp, 0, 0, width, height)
        bmp.recycle()
        return cropped
    }

    // ----------------------------------------------------------- OCR tiling

    private data class OcrLine(val box: Rect, val text: String)

    /**
     * Runs the Latin recognizer on the full image plus overlapping horizontal tiles,
     * then merges everything. Tiles exist so small text that full-image OCR skips
     * still gets caught; every bitmap is at full screenshot resolution (no scaling).
     *
     * Tile layout (for screenshot height H): 3 horizontal strips, each H/2 tall,
     * with tops at 0, H/4 and H/2 — adjacent strips overlap by H/4 (25% of the
     * screen height, 50% of a strip), so no text line is ever cut by a single
     * boundary in all passes.
     */
    private fun runOcrPipeline(snapshot: Bitmap) {
        val passes = mutableListOf<Pair<Bitmap, Int>>() // bitmap -> y offset in full image
        passes.add(snapshot to 0)
        val h = snapshot.height
        val tileHeight = max(1, h / 2)
        val tileTops = listOf(0, (h - tileHeight) / 2, h - tileHeight).distinct()
        for (top in tileTops) {
            if (top == 0) continue // full-image pass already covers it at same offset
            val tile = Bitmap.createBitmap(snapshot, 0, top, snapshot.width, min(tileHeight, h - top))
            passes.add(tile to top)
        }

        val tasks = passes.map { (bmp, _) ->
            latinRecognizer.process(InputImage.fromBitmap(bmp, 0))
        }
        Tasks.whenAllComplete(tasks).addOnCompleteListener { _ ->
            val rawLines = mutableListOf<OcrLine>()
            tasks.forEachIndexed { index, task ->
                if (task.isSuccessful) {
                    val offsetY = passes[index].second
                    extractLines(task.result, offsetY, rawLines)
                }
            }
            // Free the pass bitmaps (tiles are crops of the snapshot; snapshot included).
            passes.forEach { (bmp, _) -> if (!bmp.isRecycled) bmp.recycle() }

            val merged = deduplicate(rawLines)
            onLinesMerged(merged)
        }
    }

    private fun extractLines(visionText: Text?, yOffset: Int, out: MutableList<OcrLine>) {
        if (visionText == null) return
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val bb = line.boundingBox ?: continue
                val text = line.text.trim()
                if (text.isEmpty()) continue
                val rect = Rect(bb.left, bb.top + yOffset, bb.right, bb.bottom + yOffset)
                if (rect.width() <= 0 || rect.height() <= 0) continue
                out.add(OcrLine(rect, text))
            }
        }
    }

    /**
     * Dedup rule: two lines are the same if their boxes overlap with IoU > 0.5,
     * or if their normalized texts are equal (lowercase, non-alphanumeric stripped)
     * and IoU > 0.2. Full-image results are merged first, tile extras afterwards,
     * so the most reliable copy of each line wins.
     */
    private fun deduplicate(lines: List<OcrLine>): List<OcrLine> {
        val kept = mutableListOf<OcrLine>()
        for (candidate in lines) {
            val dup = kept.any { existing ->
                val iou = iou(existing.box, candidate.box)
                iou > 0.5f || (iou > 0.2f && normalize(candidate.text) == normalize(existing.text))
            }
            if (!dup) kept.add(candidate)
        }
        return kept
    }

    private fun iou(a: Rect, b: Rect): Float {
        val ix = max(0, min(a.right, b.right) - max(a.left, b.left))
        val iy = max(0, min(a.bottom, b.bottom) - max(a.top, b.top))
        val inter = ix.toFloat() * iy.toFloat()
        if (inter <= 0f) return 0f
        val union = a.width().toFloat() * a.height() + b.width().toFloat() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun normalize(text: String): String =
        text.lowercase().filter { it.isLetterOrDigit() }

    // ------------------------------------------------- filter + translate all

    /**
     * Line filter rule (exact):
     *  - text contains at least one Latin letter [A-Za-z]  -> English line: TRANSLATE it.
     *  - no Latin letters but at least one digit [0-9]     -> numbers line: keep, render
     *    unchanged (prices, times, counters don't need translation but must not vanish).
     *  - no Latin letters and no digits (punctuation/symbols only) -> DROP: these are
     *    almost always the Latin recognizer misreading Chinese graphics/icons.
     */
    private fun applyLineFilter(lines: List<OcrLine>): Pair<List<OcrLine>, Boolean> {
        var hasEnglish = false
        val kept = lines.filter { line ->
            val hasLatin = line.text.any { it in 'A'..'Z' || it in 'a'..'z' }
            val hasDigit = line.text.any { it.isDigit() }
            when {
                hasLatin -> { hasEnglish = true; true }
                hasDigit -> true
                else -> false
            }
        }
        return kept to hasEnglish
    }

    private fun onLinesMerged(rawLines: List<OcrLine>) {
        val (kept, hasEnglish) = applyLineFilter(rawLines)
        if (!hasEnglish) {
            hideIndicator()
            busy = false
            Toast.makeText(this, "没识别到英文", Toast.LENGTH_SHORT).show()
            return
        }
        val sorted = kept.sortedWith(compareBy({ it.box.top }, { it.box.left }))
        translateAllLines(sorted)
    }

    private class PendingLine(val box: Rect, val original: String, var display: String)

    /**
     * Translates LINE BY LINE: one ML Kit translate call per English line (never a
     * merged block, which is how v1 dropped lines). Number/symbol lines pass through
     * unchanged. A line whose translation fails even after the built-in single retry
     * falls back to showing its original text, so it never silently disappears.
     */
    private fun translateAllLines(lines: List<OcrLine>) {
        val pending = lines.map { line ->
            val needsTranslation = line.text.any { it in 'A'..'Z' || it in 'a'..'z' }
            PendingLine(line.box, line.text, line.text) to needsTranslation
        }
        val toTranslate = pending.filter { it.second }
        if (toTranslate.isEmpty()) {
            finishWithLines(pending.map { it.first })
            return
        }
        val remaining = AtomicInteger(toTranslate.size)
        for ((line, _) in toTranslate) {
            EnZhTranslator.translateLine(line.original,
                onSuccess = { translated ->
                    line.display = translated
                    if (remaining.decrementAndGet() == 0) finishWithLines(pending.map { it.first })
                },
                onFailure = {
                    line.display = line.original
                    if (remaining.decrementAndGet() == 0) finishWithLines(pending.map { it.first })
                })
        }
    }

    private fun finishWithLines(lines: List<PendingLine>) {
        mainHandler.post {
            hideIndicator()
            busy = false
            val items = lines.map { TranslationOverlayView.Item(it.box, it.display) }
            showTranslationOverlay(items)
        }
    }

    // ------------------------------------------------- in-place overlay UI

    private fun showTranslationOverlay(items: List<TranslationOverlayView.Item>) {
        dismissTranslationOverlay()
        val view = TranslationOverlayView(this, items) { dismissTranslationOverlay() }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        windowManager.addView(view, params)
        translationOverlay = view
        bringButtonToFront()
    }

    /** Re-adds the floating button so it stays visible/clickable ABOVE the overlay. */
    private fun bringButtonToFront() {
        val button = floatButton ?: return
        val params = floatParams ?: return
        try {
            windowManager.removeView(button)
            windowManager.addView(button, params)
        } catch (e: Exception) {
            // button already in desired state
        }
    }

    private fun dismissTranslationOverlay() {
        translationOverlay?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        translationOverlay = null
    }

    // ------------------------------------------------------- tiny indicator

    private fun showIndicator() {
        hideIndicator()
        val view = TextView(this).apply {
            text = "翻译中…"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#AA333333"))
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val fp = floatParams
            x = (fp?.x ?: dp(16))
            y = (fp?.y ?: dp(200)) + dp(66)
        }
        try {
            windowManager.addView(view, params)
            indicatorView = view
        } catch (e: Exception) {
            indicatorView = null
        }
    }

    private fun hideIndicator() {
        indicatorView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // already removed
            }
        }
        indicatorView = null
    }

    // -------------------------------------------------------------- destroy

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        busy = false
        hideIndicator()
        dismissTranslationOverlay()
        try {
            floatButton?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            // already removed
        }
        floatButton = null
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
        } catch (e: Exception) {
            // ignore cleanup errors
        }
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
        captureThread?.quitSafely()
        captureThread = null
        synchronized(frameLock) {
            latestFrame?.recycle()
            latestFrame = null
        }
        try {
            latinRecognizer.close()
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val ACTION_START = "com.xiaofeng.screentranslator.action.START"
        private const val ACTION_STOP = "com.xiaofeng.screentranslator.action.STOP"
        private const val EXTRA_RESULT_CODE = "extra_result_code"
        private const val EXTRA_DATA = "extra_data"
        private const val NOTIFICATION_ID = 1001

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, TranslatorService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, TranslatorService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
