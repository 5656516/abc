package com.xiaofeng.screentranslator

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.CopyOnWriteArrayList

/**
 * The single translation engine of the app: English -> Simplified Chinese, on-device.
 *
 * Model readiness is a hard gate for the whole app (v2 requirement): the EN->ZH model
 * must be fully downloaded before the floating button may translate anything. Both
 * [MainActivity] (status display) and [TranslatorService] (tap gating) share this
 * singleton, and the download starts automatically when either of them first runs.
 */
object EnZhTranslator {

    enum class ModelStatus { UNKNOWN, DOWNLOADING, READY, FAILED }

    @Volatile
    var status: ModelStatus = ModelStatus.UNKNOWN
        private set

    val isReady: Boolean get() = status == ModelStatus.READY

    private val listeners = CopyOnWriteArrayList<(ModelStatus) -> Unit>()

    fun addStatusListener(listener: (ModelStatus) -> Unit) {
        listeners.add(listener)
        listener(status)
    }

    fun removeStatusListener(listener: (ModelStatus) -> Unit) {
        listeners.remove(listener)
    }

    private fun setStatus(newStatus: ModelStatus) {
        if (status == newStatus) return
        status = newStatus
        listeners.forEach { it(newStatus) }
    }

    private val translator: Translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.CHINESE)
                .build()
        )
    }

    /**
     * Starts (or restarts after failure) the one-time EN->ZH model download.
     * Conditions deliberately do NOT require Wi-Fi, so it can finish on mobile data.
     */
    @Synchronized
    fun ensureModelDownloaded() {
        if (status == ModelStatus.READY || status == ModelStatus.DOWNLOADING) return
        setStatus(ModelStatus.DOWNLOADING)
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { setStatus(ModelStatus.READY) }
            .addOnFailureListener { setStatus(ModelStatus.FAILED) }
    }

    /**
     * Translates ONE line of English text. If the call fails, the model download is
     * re-checked and the line is retried exactly once before giving up.
     */
    fun translateLine(text: String, onSuccess: (String) -> Unit, onFailure: (Exception) -> Unit) {
        translator.translate(text)
            .addOnSuccessListener(onSuccess)
            .addOnFailureListener {
                // One retry, after making sure the model really is on the device.
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnCompleteListener {
                        if (it.isSuccessful) setStatus(ModelStatus.READY)
                        translator.translate(text)
                            .addOnSuccessListener(onSuccess)
                            .addOnFailureListener(onFailure)
                    }
            }
    }
}
