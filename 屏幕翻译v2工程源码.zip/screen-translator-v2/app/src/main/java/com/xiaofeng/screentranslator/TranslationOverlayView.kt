package com.xiaofeng.screentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Full-screen in-place translation overlay (v2 core UI).
 *
 * For every recognized line it draws an opaque light rounded rectangle exactly over
 * the line's original bounding box in the screenshot (screenshot and overlay window
 * share the same full-screen coordinate space, so coordinates map 1:1) and renders
 * the Chinese translation inside it. The underlying page therefore looks like it was
 * translated in place — there is no panel, no list and no second page.
 *
 * Any tap on this view dismisses it (handled by [onDismiss] from the touch listener).
 */
class TranslationOverlayView(
    context: Context,
    private val items: List<Item>,
    private val onDismiss: () -> Unit
) : View(context) {

    data class Item(val box: Rect, val displayText: String)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#F7F7F2") // opaque light background
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#D8D8D0")
        strokeWidth = 1.5f
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#111111")
    }

    private val density = resources.displayMetrics.density
    private val padX = 3f * density
    private val padY = 1.5f * density
    private val cornerRadius = 3f * density
    private val minTextSizePx = 8f * density

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Any tap anywhere dismisses the translation and returns to the original page.
        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_DOWN) {
            onDismiss()
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (item in items) {
            drawItem(canvas, item)
        }
    }

    private fun drawItem(canvas: Canvas, item: Item) {
        val box = item.box
        val textWidth = max(10, (box.width() - 2 * padX).toInt())
        // Start from a text size derived from the original line height, then shrink
        // until the translation fits in at most 2 lines.
        var textSize = min(box.height() * 0.78f, 22f * density)
        if (textSize < minTextSizePx) textSize = minTextSizePx
        var layout = buildLayout(item.displayText, textWidth, textSize)
        while (layout.lineCount > 2 && textSize > minTextSizePx) {
            textSize -= 1f * density
            if (textSize < minTextSizePx) textSize = minTextSizePx
            layout = buildLayout(item.displayText, textWidth, textSize)
        }
        // The box keeps the original width; its height may grow modestly so a
        // 2-line translation still fits (anchored at the line's original top).
        val bgHeight = max(box.height().toFloat(), layout.height + 2 * padY)
        val bgRect = RectF(
            box.left - padX * 0.5f,
            box.top - padY,
            box.right + padX * 0.5f,
            box.top - padY + bgHeight
        )
        canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, bgPaint)
        canvas.drawRoundRect(bgRect, cornerRadius, cornerRadius, strokePaint)

        canvas.save()
        val textY = bgRect.top + (bgHeight - layout.height) / 2f
        canvas.translate(box.left.toFloat(), textY)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun buildLayout(text: String, width: Int, textSize: Float): StaticLayout {
        textPaint.textSize = textSize
        return StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.05f)
            .setIncludePad(false)
            .build()
    }
}
