# 屏幕翻译（Screen Translator）v2

一个只做一件事的安卓 App：**把屏幕上的英文翻译成简体中文**。

在任意 App 里点一下悬浮的「译」按钮，它会截取当前屏幕、识别出所有英文，再把中文译文**直接盖在原文的位置上**显示——页面看起来就像被原地翻译了一样，不弹出第二个页面、没有结果列表。点屏幕任意位置即可关闭，回到原来的页面。

- 包名：`com.xiaofeng.screentranslator`
- minSdk 26（Android 8.0）/ targetSdk 34 / compileSdk 34
- 语言：Kotlin，原生 Android；识别与翻译使用 Google ML Kit，全部在手机本地完成

## 它是怎么做到「不漏翻」的

- **全分辨率识别**：截图不做任何缩小，用 ML Kit 拉丁文字识别器跑两遍——整屏一遍 + 3 条互相重叠的横向分片再各跑一遍（小字在整屏识别里容易漏，分片里能补回来），两遍结果按位置去重合并。
- **逐行翻译**：识别出的每一行英文都单独调用一次翻译（英→中），绝不把整段文字合并成一块去翻（合并翻译正是漏行、跳行的元凶）。纯数字/符号的行不翻译、原样显示；识别器误读出的无意义符号行会被过滤掉。
- **模型先行**：英→中离线翻译模型在打开 App 时就自动下载，界面上会显示「翻译模型：下载中/已就绪」；模型没就绪时点悬浮按钮只会提示「模型下载中，请稍候」，不会静默失败。模型只需下载一次，之后翻译全程离线、秒出。

## 如何生成 APK

### 方法一：Android Studio（推荐）

1. 安装 Android Studio（自带 JDK 17，满足要求），并在 SDK Manager 里安装 **Android 14 (API 34)** 的 SDK Platform。
2. 解压本项目，用 Android Studio 打开项目文件夹（选包含 `settings.gradle.kts` 的这一层）。
3. 等待 Gradle 同步完成（首次会联网下载 Gradle 8.7 和依赖，需要几分钟）。
4. 菜单 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**。
5. 生成的 APK 在：`app/build/outputs/apk/debug/app-debug.apk`，传到手机安装即可。

### 方法二：命令行

需要：JDK 17、Android SDK 34。

```bash
# 1. 复制 local.properties.example 为 local.properties，把 sdk.dir 改成你电脑上的 SDK 路径
cp local.properties.example local.properties

# 2. 构建（Windows 用 gradlew.bat）
./gradlew assembleDebug
```

APK 同样生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 使用说明

1. **安装**：把 APK 传到手机点开安装；若提示禁止安装未知来源应用，在系统设置里给文件管理器/浏览器一次允许即可。
2. **打开 App**，按页面三步走：
   - 第 1 步：开启悬浮窗权限；
   - 第 2 步：等「英→中翻译模型」显示 **已就绪 ✓**（首次需联网下载，几十 MB，只下一次）；
   - 第 3 步：点「启动悬浮按钮」。
3. **录屏授权**：每次启动悬浮按钮，安卓系统都会弹框要求同意录屏/截屏——**这是安卓系统的硬性规定，任何 App 都绕不过**，点「立即开始」即可。
4. **翻译**：去任意有英文的页面（游戏、网页、外文 App 都行），点悬浮的「译」按钮，稍等片刻，中文译文就会直接出现在原文位置上；点屏幕任意位置关闭译文；按住按钮可以拖动位置；译文显示时点「译」按钮也可以关闭译文。
5. 如果当前页面没有英文，会提示「没识别到英文」。

## 隐私

截图只在手机本地做识别和翻译，不上传任何服务器；除首次下载 ML Kit 离线翻译模型外，App 不需要联网工作。

## 技术栈

- ML Kit Text Recognition（Latin）16.0.1 —— 本地 OCR
- ML Kit Translate 17.0.3 —— 本地英→中翻译
- MediaProjection + ImageReader —— 全屏截图
- WindowManager 悬浮窗 —— 悬浮按钮 + 全屏原位译文覆盖层
- 前台服务（mediaProjection 类型，符合 Android 14 规范）
