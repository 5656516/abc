#!/usr/bin/env bash
set -e
echo "========================================================"
echo "  正在编译【极译 · 全屏原位英译汉】安装包 (.apk)..."
echo "========================================================"
if [ -f "./gradlew" ]; then
    chmod +x ./gradlew
    ./gradlew assembleRelease
else
    gradle assembleRelease
fi
echo ""
echo "✅ 编译完成！可直接安装到安卓手机的 APK 文件位置："
echo "app/build/outputs/apk/release/app-release.apk"
