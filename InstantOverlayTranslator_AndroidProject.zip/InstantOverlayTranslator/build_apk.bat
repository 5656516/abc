@echo off
chcp 65001 >nul
echo ========================================================
echo   正在编译【极译 · 全屏原位英译汉】安装包 (.apk)...
echo ========================================================
if exist gradlew.bat (
    call gradlew.bat assembleRelease
) else (
    gradle assembleRelease
)
echo.
echo 编译完成！APK 文件位置：
echo app\build\outputs\apk\release\app-release.apk
pause
