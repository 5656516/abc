# 极译 (InstantOverlayTranslator) —— 安卓全屏原位英译汉软件工程

本项目专为你的需求定制打造：**只做一件事，把屏幕上的所有英文极速、高水准（雅思 7.5+）地原位翻译成中文，绝不出现第二个页面！**

---

## 一、核心特性（极致单向英译汉 + 零二级页面）

1. **真正的“当前页原位覆盖翻译”（绝不跳转第二页面）**
   - 屏幕侧边常驻一枚轻巧可拖拽的 **【译】** 悬浮球（设置了 `FLAG_NOT_FOCUSABLE`，绝不抢夺当前 App 焦点，不影响打字和滑动）。
   - 在任何 App、网页、论文、图片或外服游戏中，只要点一下 **【译】**，软件立即在 **30ms 内** 读取当前屏幕上所有英文及其精确像素坐标 `Rect`，并发翻译后 **直接在原来英文的位置上覆盖绘制高对比度圆角中文卡片**。
   - **全程停留在当前页面**，不弹窗、不切换 Activity、不打断阅读体验。轻触屏幕任意位置或再点一次悬浮球即可瞬间恢复原画面。

2. **凡有英文必翻译（无障碍节点树 + Android 11+ 无感静默截屏 OCR 双引擎）**
   - **第一路（15ms 极速）**：遍历当前窗口 `AccessibilityNodeInfo` 节点树，提取所有含英文的控件文字与屏幕坐标。
   - **第二路（图像/游戏/自绘控件全覆盖）**：调用 Android 11+ 无障碍原生静默截屏 + Google ML Kit 端侧文字识别，哪怕是图片里的英文、漫画对话框、PDF 或游戏界面，也能无需任何授权弹窗直接原位翻译。

3. **堪比雅思 7.5+ 水准 & 极速三层并发翻译架构**
   - **L1 毫秒级内存缓存 (`LruCache`)**：常见英文 UI 按钮、高频学术词汇与已翻段落 **0ms 瞬时返回**。
   - **雅思 7.5+ 并发大模型引擎**：内置针对雅思考官级长难句重构的专属 Prompt（自动拆解定语从句、被动语态，消除生硬机翻腔），将整屏所有英文块打包为单次 HTTP/2 请求并发返回。
   - **免配置极速神经引擎 + 端侧离线模型兜底**：无需配置任何 API Key 即可开箱即用（并发请求高精神经翻译 + Google ML Kit 离线英译汉模型自动兜底）。

---

## 二、如何用这个压缩包生成 `.apk` 安装到安卓手机？

你可以任选以下 **3 种方式之一** 生成 `.apk`（**方式 1 适合只有手机、没有电脑的用户**；**方式 2/3 适合有电脑的用户**）：

### 方式 1：无需电脑！直接用手机上传到 GitHub 自动生成 `.apk`（推荐）
本项目已内置 `.github/workflows/build-apk.yml` 云端自动编译脚本：
1. 在 GitHub 新建一个仓库，把解压后的文件上传上去（或在手机浏览器上传）。
2. 点击仓库顶部的 **Actions** 标签页 -> 选择 **Build Android APK** -> 点击 **Run workflow**。
3. 等待约 2 分钟编译完成，在页面底部的 **Artifacts** 处点击 **`InstantOverlayTranslator-APK`** 即可直接下载编译好的 `app-release.apk` 到手机安装！

### 方式 2：使用 Android Studio 一键生成 `.apk`
1. 解压本压缩包，打开 **Android Studio** -> **Open** 选择解压后的 `InstantOverlayTranslator` 文件夹。
2. 等待 Gradle 同步完成后，点击顶部菜单栏：**Build -> Build Bundle(s) / APK(s) -> Build APK(s)**。
3. 编译生成的安装包位于：`app/build/outputs/apk/debug/app-debug.apk` 或 `app/build/outputs/apk/release/app-release.apk`（已默认配置好可直接安装的签名）。

### 方式 3：命令行一键双击脚本生成 `.apk`
- **Windows**：双击运行根目录下的 `build_apk.bat`
- **macOS / Linux**：在终端运行 `./build_apk.sh`
- 生成的 `.apk` 路径：`app/build/outputs/apk/release/app-release.apk`
