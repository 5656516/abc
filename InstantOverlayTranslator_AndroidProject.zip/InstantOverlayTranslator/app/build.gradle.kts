plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.extreme.instanttranslator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.extreme.instanttranslator"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // 使用默认 debug 签名方便直接生成可安装的 APK，也可自行配置签名
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // Coroutines for ultra-fast parallel screen scanning & concurrent batch translation
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // OkHttp with HTTP/2 connection pooling for low-latency concurrent API calls
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Google ML Kit Text Recognition (for in-place OCR on images/games/custom canvas views)
    implementation("com.google.mlkit:text-recognition:16.0.0")

    // Google ML Kit On-Device Translation (offline ultra-fast fallback)
    implementation("com.google.mlkit:translate:17.0.2")
}
