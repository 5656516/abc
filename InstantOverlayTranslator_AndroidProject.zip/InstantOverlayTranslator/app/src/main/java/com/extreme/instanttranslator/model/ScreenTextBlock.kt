package com.extreme.instanttranslator.model

import android.graphics.Rect

/**
 * 表示屏幕上提取到的单个英文文本块及其精确屏幕像素坐标
 */
data class ScreenTextBlock(
    val id: Int,
    val originalEnglish: String,
    val boundsInScreen: Rect,
    var translatedChinese: String = "",
    val isFromOcr: Boolean = false
)
