package com.extreme.instanttranslator

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.extreme.instanttranslator.service.FloatingTranslatorService
import com.extreme.instanttranslator.translation.TranslationEngine
import kotlinx.coroutines.launch

/**
 * 极简权限授权与悬浮球启动器：
 * 开启悬浮球后自动退到桌面/后台，后续用户在任何 App 内只需点悬浮球“译”，
 * 即可直接在当前页面原位置把所有英文变成地道中文，绝不弹出第二个页面。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvAccessibilityStatus: TextView
    private lateinit var etApiEndpoint: EditText
    private lateinit var etApiModel: EditText
    private lateinit var etApiKey: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvOverlayStatus = findViewById(R.id.tvOverlayStatus)
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus)
        etApiEndpoint = findViewById(R.id.etApiEndpoint)
        etApiModel = findViewById(R.id.etApiModel)
        etApiKey = findViewById(R.id.etApiKey)

        val prefs = getSharedPreferences("translator_prefs", Context.MODE_PRIVATE)
        etApiEndpoint.setText(prefs.getString("api_endpoint", "https://api.deepseek.com"))
        etApiModel.setText(prefs.getString("api_model", "deepseek-chat"))
        etApiKey.setText(prefs.getString("api_key", ""))

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnGrantAccessibility).setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(
                this,
                "请在已下载的应用中找到【极译·屏幕英文极速原位识别服务】并开启",
                Toast.LENGTH_LONG
            ).show()
        }

        findViewById<Button>(R.id.btnSaveConfig).setOnClickListener {
            prefs.edit()
                .putString("api_endpoint", etApiEndpoint.text.toString().trim())
                .putString("api_model", etApiModel.text.toString().trim())
                .putString("api_key", etApiKey.text.toString().trim())
                .apply()

            lifecycleScope.launch {
                TranslationEngine(applicationContext).preloadOfflineModel()
                Toast.makeText(
                    this@MainActivity,
                    "引擎配置已保存，离线加速词库已就绪！",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        findViewById<Button>(R.id.btnStartFloating).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先完成第1步：开启悬浮窗权限", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "请先完成第1步：开启无障碍屏幕识别服务", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val serviceIntent = Intent(this, FloatingTranslatorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }

            // 启动悬浮球后立即退回桌面/原应用，绝不打断用户操作
            moveTaskToBack(true)
        }

        findViewById<Button>(R.id.btnStopFloating).setOnClickListener {
            stopService(Intent(this, FloatingTranslatorService::class.java))
            Toast.makeText(this, "已关闭悬浮球", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
    }

    private fun refreshPermissionStatus() {
        val hasOverlay = Settings.canDrawOverlays(this)
        tvOverlayStatus.text = if (hasOverlay) {
            "✅ 悬浮窗权限：已开启"
        } else {
            "❌ 悬浮窗权限：未开启（点击下方按钮授权）"
        }
        tvOverlayStatus.setTextColor(
            if (hasOverlay) Color.parseColor("#16A34A") else Color.parseColor("#DC2626")
        )

        val hasA11y = isAccessibilityServiceEnabled()
        tvAccessibilityStatus.text = if (hasA11y) {
            "✅ 无障碍屏幕英文提取服务：已开启"
        } else {
            "❌ 无障碍屏幕英文提取服务：未开启（点击下方按钮授权）"
        }
        tvAccessibilityStatus.setTextColor(
            if (hasA11y) Color.parseColor("#16A34A") else Color.parseColor("#DC2626")
        )
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any {
            it.resolveInfo.serviceInfo.packageName == packageName
        }
    }
}
