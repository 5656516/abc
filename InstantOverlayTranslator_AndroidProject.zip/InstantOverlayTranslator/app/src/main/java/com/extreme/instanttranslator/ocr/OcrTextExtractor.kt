package com.extreme.instanttranslator.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.extreme.instanttranslator.util.EnglishTextFilter
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/**
 * 屏幕图像英文 OCR 识别器：
 * 针对图片、游戏画面、视频英文字幕、Canvas 自绘界面等无障碍节点无法直接拿到文本的场景，
 * 直接对屏幕位图进行毫秒级拉丁文/英文检测，提取精确到行的屏幕坐标 Rect。
 */
object OcrTextExtractor {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun extractEnglishFromBitmap(bitmap: Bitmap): List<Pair<String, Rect>> {
        val results = mutableListOf<Pair<String, Rect>>()
        try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val visionText = recognizer.process(image).await()

            for (block in visionText.textBlocks) {
                for (line in block.lines) {
                    val lineText = line.text.trim()
                    val box = line.boundingBox
                    if (box != null && EnglishTextFilter.containsTranslatableEnglish(lineText)) {
                        results.add(EnglishTextFilter.normalizeEnglishText(lineText) to Rect(box))
                    }
                }
            }
        } catch (_: Exception) {
            // 忽略单帧 OCR 异常
        }
        return results
    }
}
