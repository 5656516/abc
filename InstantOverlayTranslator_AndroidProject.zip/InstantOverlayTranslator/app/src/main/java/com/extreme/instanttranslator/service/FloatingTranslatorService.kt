package com.extreme.instanttranslator.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.extreme.instanttranslator.MainActivity
import com.extreme.instanttranslator.translation.TranslationEngine
import com.extreme.instanttranslator.ui.InPlaceTranslationOverlayView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * 极速悬浮窗翻译服务：
 * - 在屏幕侧边提供一个可自由拖拽的“译”字悬浮球。
 * - 用户在任何 App 页面点击“译”字，立即扫描当前页面全部英文，并发翻译成雅思7.5+水准中文，
 *   直接在当前页面原坐标覆盖渲染，全程不打开任何第二个页面或弹窗！
 * - 再次点击“译”或轻触屏幕任意位置即可秒关译文图层，继续顺畅操作原 App。
 */
class FloatingTranslatorService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingBubbleView: TextView
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var overlayView: InPlaceTranslationOverlayView? = null
    private var isOverlayShowing = false
    private var isTranslating = false

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var translationEngine: TranslationEngine

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        translationEngine = TranslationEngine(applicationContext)

        startForegroundNotification()
        createFloatingBubble()

        // 后台预热本地离线模型
        serviceScope.launch {
            translationEngine.preloadOfflineModel()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * 创建常驻“译”字悬浮球（不抢焦点、不影响当前页面输入与滚动）
     */
    private fun createFloatingBubble() {
        val density = resources.displayMetrics.density
        val sizePx = (54 * density).toInt()

        floatingBubbleView = TextView(this).apply {
            text = "译"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            paint.isFakeBoldText = true
            gravity = Gravity.CENTER
            background = buildBubbleDrawable("#2563EB")
            elevation = 12f * density
        }

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - sizePx - (12 * density).toInt()
            y = (resources.displayMetrics.heightPixels * 0.42f).toInt()
        }

        setupBubbleTouchListener()
        windowManager.addView(floatingBubbleView, bubbleParams)
    }

    private fun setupBubbleTouchListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        floatingBubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isDragging = true
                        bubbleParams.x = initialX + dx
                        bubbleParams.y = initialY + dy
                        windowManager.updateViewLayout(floatingBubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        onFloatingBubbleClicked()
                    } else {
                        // 自动贴边吸附，避免遮挡阅读视野
                        val screenW = resources.displayMetrics.widthPixels
                        bubbleParams.x = if (bubbleParams.x + floatingBubbleView.width / 2 < screenW / 2) {
                            12
                        } else {
                            screenW - floatingBubbleView.width - 12
                        }
                        windowManager.updateViewLayout(floatingBubbleView, bubbleParams)
                    }
                    true
                }
                else -> false
            }
        }
    }

    /**
     * 点击“译”悬浮球：
     * - 若当前已显示原位译文层，则一键关闭；
     * - 否则直接在当前页面抓取全部英文 -> 并发极速翻译 -> 原位置直接覆盖显示中文！
     */
    private fun onFloatingBubbleClicked() {
        if (isTranslating) return

        if (isOverlayShowing) {
            dismissInPlaceOverlay()
            return
        }

        val a11yService = ScreenTextAccessibilityService.instance
        if (a11yService == null) {
            Toast.makeText(
                this,
                "请先在【极译】中开启无障碍屏幕识别服务，即可一键原位翻译",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        serviceScope.launch {
            isTranslating = true
            updateBubbleState(text = "…", colorHex = "#D97706")

            try {
                // 扫描前短暂隐藏悬浮球 30ms，防止截屏 OCR 把悬浮球自身拍进去
                floatingBubbleView.visibility = View.INVISIBLE
                delay(30)

                val blocks = a11yService.captureAllEnglishOnScreen()
                floatingBubbleView.visibility = View.VISIBLE

                if (blocks.isEmpty()) {
                    Toast.makeText(
                        this@FloatingTranslatorService,
                        "当前页面未检测到英文内容",
                        Toast.LENGTH_SHORT
                    ).show()
                    updateBubbleState(text = "译", colorHex = "#2563EB")
                    isTranslating = false
                    return@launch
                }

                // 并发极速批量英译汉
                val englishList = blocks.map { it.originalEnglish }
                val translationMap = translationEngine.translateBatch(englishList)

                blocks.forEach { block ->
                    block.translatedChinese = translationMap[block.originalEnglish].orEmpty()
                }

                // 直接在当前页面原坐标渲染中文覆盖层，绝不打开第二个页面
                showInPlaceOverlay(blocks)
                updateBubbleState(text = "原", colorHex = "#16A34A")
            } catch (e: Exception) {
                floatingBubbleView.visibility = View.VISIBLE
                updateBubbleState(text = "译", colorHex = "#2563EB")
                Toast.makeText(
                    this@FloatingTranslatorService,
                    "翻译出错: ${e.localizedMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            } finally {
                isTranslating = false
            }
        }
    }

    private fun showInPlaceOverlay(blocks: List<com.extreme.instanttranslator.model.ScreenTextBlock>) {
        dismissInPlaceOverlay()

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        val view = InPlaceTranslationOverlayView(this) {
            dismissInPlaceOverlay()
        }
        view.updateTranslatedBlocks(blocks)

        // 先添加全屏原位译文层，再把“译”悬浮球置于最顶层以便随时点击切换
        windowManager.addView(view, overlayParams)
        overlayView = view
        isOverlayShowing = true

        try {
            windowManager.removeView(floatingBubbleView)
            windowManager.addView(floatingBubbleView, bubbleParams)
        } catch (_: Exception) {}
    }

    private fun dismissInPlaceOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }
        overlayView = null
        isOverlayShowing = false
        updateBubbleState(text = "译", colorHex = "#2563EB")
    }

    private fun updateBubbleState(text: String, colorHex: String) {
        floatingBubbleView.text = text
        floatingBubbleView.background = buildBubbleDrawable(colorHex)
    }

    private fun buildBubbleDrawable(colorHex: String): GradientDrawable {
        val density = resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(colorHex))
            setStroke((2f * density).toInt(), Color.WHITE)
        }
    }

    private fun startForegroundNotification() {
        val channelId = "instant_overlay_translator_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "极译悬浮窗常驻服务",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("极译 · 全屏原位英译汉运行中")
            .setContentText("在任意页面点击【译】悬浮球，即可直接在当前页面原位显示中文")
            .setSmallIcon(android.R.drawable.ic_menu_sort_alphabetically)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        dismissInPlaceOverlay()
        try {
            windowManager.removeView(floatingBubbleView)
        } catch (_: Exception) {}
        serviceScope.cancel()
    }
}
