package com.extreme.instanttranslator.util

import android.graphics.Rect

/**
 * 严格筛选屏幕上的所有有效英文文本（凡是有英文都要翻译，同时过滤纯数字/乱码/极小无效噪点）
 */
object EnglishTextFilter {

    // 匹配至少包含一个2字母以上英文单词，或包含常见单字母英文主语(I/a/A)与其它英文组合
    private val ENGLISH_WORD_REGEX = Regex("[A-Za-z]{2,}")
    private val URL_OR_EMAIL_ONLY_REGEX = Regex("^(https?://\\S+|www\\.\\S+|\\S+@\\S+\\.\\S+)$", RegexOption.IGNORE_CASE)

    /**
     * 判断文本是否包含需要翻译的英文
     */
    fun containsTranslatableEnglish(raw: String?): Boolean {
        if (raw.isNullOrBlank()) return false
        val text = raw.trim()
        if (text.length < 2) return false

        // 必须含有英文字母词
        if (!ENGLISH_WORD_REGEX.containsMatchIn(text)) return false

        // 排除纯网址或纯邮箱
        if (URL_OR_EMAIL_ONLY_REGEX.matches(text)) return false

        // 统计英文字母数量
        val englishCharCount = text.count { it in 'a'..'z' || it in 'A'..'Z' }
        return englishCharCount >= 2
    }

    /**
     * 规范化待翻译英文文本，合并多余换行以提升长难句语法还原度
     */
    fun normalizeEnglishText(raw: String): String {
        return raw
            .replace("\r\n", " ")
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * 去重与合并高度重叠的同位置文本块（防止外层ViewGroup与内层TextView重复绘制）
     */
    fun deduplicateBlocks(
        candidates: List<Pair<String, Rect>>,
        screenWidth: Int,
        screenHeight: Int
    ): List<Pair<String, Rect>> {
        val valid = candidates.filter { (text, rect) ->
            rect.width() > 16 &&
                rect.height() > 12 &&
                rect.right > 0 &&
                rect.bottom > 0 &&
                rect.left < screenWidth &&
                rect.top < screenHeight &&
                containsTranslatableEnglish(text)
        }

        // 按面积从小到大排序（优先保留最精确的子节点TextView，去除包裹整屏的父容器重复文本）
        val sorted = valid.sortedBy { (_, rect) -> rect.width().toLong() * rect.height().toLong() }
        val accepted = mutableListOf<Pair<String, Rect>>()

        for (candidate in sorted) {
            val (candText, candRect) = candidate
            val normText = normalizeEnglishText(candText)

            val isDuplicate = accepted.any { (existText, existRect) ->
                val sameText = existText.equals(normText, ignoreCase = true)
                val overlap = calculateIoU(candRect, existRect) > 0.65f
                val containsAlready = candRect.contains(existRect) &&
                    normText.contains(existText, ignoreCase = true) &&
                    (candRect.height() > existRect.height() * 2)
                (sameText && overlap) || containsAlready
            }

            if (!isDuplicate) {
                accepted.add(normText to Rect(candRect))
            }
        }

        // 按屏幕从上到下、从左到右排序，保证上下文语序自然
        return accepted.sortedWith(compareBy({ it.second.top / 24 }, { it.second.left }))
    }

    private fun calculateIoU(a: Rect, b: Rect): Float {
        val left = maxOf(a.left, b.left)
        val top = maxOf(a.top, b.top)
        val right = minOf(a.right, b.right)
        val bottom = minOf(a.bottom, b.bottom)
        if (right <= left || bottom <= top) return 0f
        val intersection = (right - left).toFloat() * (bottom - top).toFloat()
        val areaA = a.width().toFloat() * a.height().toFloat()
        val areaB = b.width().toFloat() * b.height().toFloat()
        val union = areaA + areaB - intersection
        return if (union <= 0f) 0f else intersection / union
    }
}
