package com.extreme.instanttranslator.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.extreme.instanttranslator.model.ScreenTextBlock
import com.extreme.instanttranslator.ocr.OcrTextExtractor
import com.extreme.instanttranslator.util.EnglishTextFilter
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * 无障碍全屏英文提取服务：
 * 1. 极速遍历当前活动窗口的所有可见节点，10ms 内抓取所有包含英文的控件及其屏幕坐标 Rect。
 * 2. 自动结合 Android 11+ 无感截屏 OCR（无需弹窗确认），连图片里的英文、游戏/视频英文也一网打尽。
 */
class ScreenTextAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScreenTextAccessibilityService? = null
            private set
    }

    private val screenshotExecutor = Executors.newSingleThreadExecutor()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 仅在用户点击“译”悬浮球时主动按需扫描，平时零耗电、零后台开销
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
    }

    /**
     * 一键抓取当前页面上的所有英文文本块与精确屏幕坐标
     */
    suspend fun captureAllEnglishOnScreen(): List<ScreenTextBlock> {
        val metrics = resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels
        val rawCandidates = mutableListOf<Pair<String, Rect>>()

        // 第一路：极速遍历当前窗口无障碍节点树 (<15ms)
        val rootNode = rootInActiveWindow
        if (rootNode != null) {
            traverseNode(rootNode, rawCandidates)
        }

        // 第二路：若页面节点过少（例如图片、漫画、PDF、游戏、WebView画布）或支持 Android 11+ 静默截屏，补充 OCR 识别
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bitmap = takeSilentScreenshot()
            if (bitmap != null) {
                try {
                    val ocrBlocks = OcrTextExtractor.extractEnglishFromBitmap(bitmap)
                    rawCandidates.addAll(ocrBlocks)
                } finally {
                    bitmap.recycle()
                }
            }
        }

        // 智能去重并过滤纯中文/纯数字，凡含英文全部保留
        val deduplicated = EnglishTextFilter.deduplicateBlocks(
            candidates = rawCandidates,
            screenWidth = screenWidth,
            screenHeight = screenHeight
        )

        return deduplicated.mapIndexed { idx, (enText, rect) ->
            ScreenTextBlock(
                id = idx,
                originalEnglish = enText,
                boundsInScreen = rect
            )
        }
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo?,
        outList: MutableList<Pair<String, Rect>>
    ) {
        if (node == null) return
        if (!node.isVisibleToUser) return

        // 跳过我们自己的应用悬浮窗，避免自循环
        val pkg = node.packageName?.toString().orEmpty()
        if (pkg == packageName) return

        val text = node.text?.toString()?.takeIf { it.isNotBlank() }
            ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }

        if (!text.isNullOrBlank() && EnglishTextFilter.containsTranslatableEnglish(text)) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty) {
                outList.add(text to rect)
            }
        }

        val childCount = node.childCount
        for (i in 0 until childCount) {
            val child = node.getChild(i)
            if (child != null) {
                traverseNode(child, outList)
            }
        }
    }

    /**
     * Android 11 (API 30+) 原生无障碍静默截屏（无需 MediaProjection 弹窗，完全停留在当前页）
     */
    private suspend fun takeSilentScreenshot(): Bitmap? = suspendCancellableCoroutine { cont ->
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                screenshotExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hwBuffer = screenshot.hardwareBuffer
                            val colorSpace = screenshot.colorSpace
                            val hwBitmap = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                            val softBitmap = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                            hwBitmap?.recycle()
                            hwBuffer.close()
                            if (cont.isActive) cont.resume(softBitmap)
                        } catch (_: Exception) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            )
        } catch (_: Exception) {
            if (cont.isActive) cont.resume(null)
        }
    }
}
