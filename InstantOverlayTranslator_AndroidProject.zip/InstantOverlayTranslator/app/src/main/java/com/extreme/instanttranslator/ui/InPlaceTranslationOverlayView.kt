package com.extreme.instanttranslator.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import com.extreme.instanttranslator.model.ScreenTextBlock
import kotlin.math.max
import kotlin.math.min

/**
 * 原位翻译全屏透明画布（核心“零二级页面”体验）：
 * 直接在当前页面原本显示英文的精确坐标（Rect）上方，绘制高对比度圆角磨砂卡片与自适应字号的中文译文。
 * 轻触屏幕任意位置即可一键清除译文层，恢复原页面操作。
 */
class InPlaceTranslationOverlayView(
    context: Context,
    private val onDismissRequested: () -> Unit
) : View(context) {

    private var blocks: List<ScreenTextBlock> = emptyList()
    private val density = resources.displayMetrics.density
    private val scaledDensity = resources.displayMetrics.scaledDensity

    // 卡片背景画笔（深色高对比度半透明底色，确保盖住底层英文且清晰易读）
    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EE0F172A")
        style = Paint.Style.FILL
    }

    // 卡片精致描边画笔
    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6638BDF8")
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * density
    }

    // 顶部状态提示条背景画笔
    private val bannerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E61E3A8A")
        style = Paint.Style.FILL
    }

    // 译文文字画笔
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F8FAFC")
    }

    private val bannerTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 12.5f * scaledDensity
        isFakeBoldText = true
    }

    fun updateTranslatedBlocks(newBlocks: List<ScreenTextBlock>) {
        this.blocks = newBlocks.filter { it.translatedChinese.isNotBlank() }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (blocks.isEmpty()) return

        val padH = 6f * density
        val padV = 3f * density
        val cornerRadius = 6f * density

        for (block in blocks) {
            val rect = block.boundsInScreen
            val cardRect = RectF(
                max(4f, rect.left.toFloat() - 2f * density),
                max(4f, rect.top.toFloat() - 1f * density),
                min(width - 4f, rect.right.toFloat() + 2f * density),
                min(height - 4f, rect.bottom.toFloat() + 2f * density)
            )

            val availWidth = max(48, (cardRect.width() - padH * 2).toInt())
            val availHeight = max(20f, cardRect.height() - padV * 2)

            // 自适应计算最佳中文字号，使译文完美契合原英文框尺寸
            var fontSizeSp = 15f
            var staticLayout = buildStaticLayout(block.translatedChinese, availWidth, fontSizeSp)

            while (staticLayout.height > availHeight && fontSizeSp > 9.5f) {
                fontSizeSp -= 1f
                staticLayout = buildStaticLayout(block.translatedChinese, availWidth, fontSizeSp)
            }

            // 如果原英文是多行长段且译文高度略超，适度向下延展背景框以完整显示全部中文
            val finalBottom = max(cardRect.bottom, cardRect.top + staticLayout.height + padV * 2)
            cardRect.bottom = min(height - 4f, finalBottom)

            // 绘制原位覆盖背景卡片与边框
            canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, cardBgPaint)
            canvas.drawRoundRect(cardRect, cornerRadius, cornerRadius, cardBorderPaint)

            // 垂直居中绘制中文译文
            canvas.save()
            val textY = cardRect.top + max(padV, (cardRect.height() - staticLayout.height) / 2f)
            canvas.translate(cardRect.left + padH, textY)
            staticLayout.draw(canvas)
            canvas.restore()
        }

        // 顶部绘制迷你操作提示胶囊：“已原位翻译 X 处英文 · 轻触任意处返回原画面”
        val tip = "已原位精译 ${blocks.size} 处英文 · 轻触屏幕任意位置恢复操作"
        val tipWidth = bannerTextPaint.measureText(tip) + 28f * density
        val tipLeft = (width - tipWidth) / 2f
        val tipTop = 38f * density
        val tipRect = RectF(tipLeft, tipTop, tipLeft + tipWidth, tipTop + 30f * density)
        canvas.drawRoundRect(tipRect, 15f * density, 15f * density, bannerPaint)
        canvas.drawText(
            tip,
            tipLeft + 14f * density,
            tipTop + 20f * density,
            bannerTextPaint
        )
    }

    private fun buildStaticLayout(text: String, widthPx: Int, textSizeSp: Float): StaticLayout {
        textPaint.textSize = textSizeSp * scaledDensity
        return StaticLayout.Builder
            .obtain(text, 0, text.length, textPaint, widthPx)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.08f)
            .setIncludePad(false)
            .build()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            onDismissRequested.invoke()
            return true
        }
        return super.onTouchEvent(event)
    }
}
